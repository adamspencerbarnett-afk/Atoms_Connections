@echo off
rem Opens Atom's Connections with this PC's protection. Double-click to start.
start "" powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "%~dp0launcher.ps1"
