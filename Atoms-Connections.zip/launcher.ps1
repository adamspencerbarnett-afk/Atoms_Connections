# Atom's Connections launcher (Windows).
# Serves the app at http://127.0.0.1:47800 and gives the page this PC's secret, which Windows seals (DPAPI)
# to the current user account on this computer. Copying the app's data to another PC or account cannot unseal it.
# It also writes backups into the user's Pictures and Documents folders. It stops itself a couple of minutes
# after the app's last page is closed (the page tells it), or after a long time with no activity at all.
param(
  [int]$Port = 47800,
  [string]$DataDir = (Join-Path $env:LOCALAPPDATA 'AtomsConnections'),
  [string]$PicturesDir = [Environment]::GetFolderPath('MyPictures', 'DoNotVerify'),
  [string]$DocumentsDir = [Environment]::GetFolderPath('MyDocuments', 'DoNotVerify'),
  [int]$ByeExitSeconds = 120,
  [int]$IdleExitMinutes = 360,
  [switch]$NoBrowser
)
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Security
$Url = "http://127.0.0.1:$Port/"
if (-not $PicturesDir) { $PicturesDir = Join-Path $env:USERPROFILE 'Pictures' }
if (-not $DocumentsDir) { $DocumentsDir = Join-Path $env:USERPROFILE 'Documents' }

function Fail([string]$why) {
  try { Add-Type -AssemblyName System.Windows.Forms; [Windows.Forms.MessageBox]::Show("Atom's Connections could not start.`n`n$why", "Atom's Connections") | Out-Null } catch { Write-Error $why }
  exit 1
}

# Already running? Just open the app.
try {
  $r = Invoke-WebRequest -UseBasicParsing -Uri "${Url}ping" -TimeoutSec 2
  if ($r.Content -eq 'atoms-connections') { if (-not $NoBrowser) { Start-Process $Url }; exit }
} catch {}

try {
  # This PC's secret: 32 random bytes, stored only in DPAPI-protected form.
  New-Item -ItemType Directory -Force -Path $DataDir | Out-Null
  $keyFile = Join-Path $DataDir 'device.key'
  $scope = [Security.Cryptography.DataProtectionScope]::CurrentUser
  if (Test-Path $keyFile) {
    try { $secret = [Security.Cryptography.ProtectedData]::Unprotect([IO.File]::ReadAllBytes($keyFile), $null, $scope) }
    catch { Fail "This PC's key file can't be read by this Windows account ($keyFile). If you moved it from another computer, delete it to start fresh." }
  } else {
    $secret = New-Object byte[] 32
    [Security.Cryptography.RandomNumberGenerator]::Create().GetBytes($secret)
    [IO.File]::WriteAllBytes($keyFile, [Security.Cryptography.ProtectedData]::Protect($secret, $null, $scope))
  }
  foreach ($f in @('index.html', 'vendor\peerjs.min.js')) { if (-not (Test-Path (Join-Path $PSScriptRoot $f))) { Fail "The file '$f' is missing. Keep all the files from the zip together in one folder." } }
  $listener = New-Object Net.HttpListener
  $listener.Prefixes.Add($Url)
  try { $listener.Start() } catch { Fail "Another program is already using port $Port on this computer. ($($_.Exception.Message))" }
} catch { Fail $_.Exception.Message }

$static = @{
  '/'                     = @('index.html', 'text/html; charset=utf-8')
  '/index.html'           = @('index.html', 'text/html; charset=utf-8')
  '/vendor/peerjs.min.js' = @('vendor\peerjs.min.js', 'text/javascript; charset=utf-8')
}
$saveRoots = @{ pictures = (Join-Path $PicturesDir "Atom's Connections"); documents = (Join-Path $DocumentsDir "Atom's Connections") }

function Send($res, [int]$code, [byte[]]$bytes, [string]$type) {
  $res.StatusCode = $code
  if ($bytes) { $res.ContentType = $type; $res.ContentLength64 = $bytes.Length; $res.OutputStream.Write($bytes, 0, $bytes.Length) }
}
function Query($req) {   # decoded as UTF-8 (HttpListener's own QueryString assumes Windows-1252 for these requests)
  $q = @{}
  foreach ($kv in $req.Url.Query.TrimStart('?').Split('&')) {
    $i = $kv.IndexOf('=')
    if ($i -gt 0) { $q[[Uri]::UnescapeDataString($kv.Substring(0, $i))] = [Uri]::UnescapeDataString($kv.Substring($i + 1)) }
  }
  return $q
}
function SafeTarget([string]$folder, [string]$rel) {
  # Only "Name" or "Folder/Name" below the app's own folder in Pictures or Documents.
  if (-not $saveRoots.ContainsKey($folder) -or -not $rel) { return $null }
  $parts = $rel -split '/'
  if ($parts.Count -gt 2) { return $null }
  foreach ($p in $parts) { if ($p -notmatch '^[^\\/:*?"<>|\x00-\x1f]{1,120}$' -or $p -match '^\.+$' -or $p -match '[. ]$' -or $p -match '^(con|prn|aux|nul|com[1-9]|lpt[1-9])(\.|$)') { return $null } }
  $root = $saveRoots[$folder]
  $full = [IO.Path]::GetFullPath((Join-Path $root ($parts -join '\')))
  if (-not $full.StartsWith($root + '\', [StringComparison]::OrdinalIgnoreCase)) { return $null }
  return $full
}

if (-not $NoBrowser) { Start-Process $Url }
$utf8 = [Text.Encoding]::UTF8
$idle = 0          # 5-second waits with no request (counts real waits, so a sleeping PC doesn't count)
$byeIdle = -1      # waits since the page said goodbye; -1 = page still open

while ($listener.IsListening) {
  $task = $listener.GetContextAsync()
  while (-not $task.AsyncWaitHandle.WaitOne(5000)) {
    $idle++
    if ($byeIdle -ge 0) { $byeIdle++ }
    if (($byeIdle -ge 0 -and $byeIdle * 5 -ge $ByeExitSeconds) -or $idle * 5 -ge $IdleExitMinutes * 60) { $listener.Stop(); exit }
  }
  $ctx = $task.Result; $idle = 0
  $req = $ctx.Request; $res = $ctx.Response
  try {
    $res.Headers['Cache-Control'] = 'no-store'
    $res.Headers['X-Content-Type-Options'] = 'nosniff'
    $path = $req.Url.AbsolutePath
    $sameSite = $req.Headers['Sec-Fetch-Site'] -ne 'cross-site'
    # Only this exact address; blocks other websites (including DNS-rebinding tricks).
    if ($req.Headers['Host'] -ne "127.0.0.1:$Port") { Send $res 403 $null $null }
    elseif ($path -eq '/ping') { $byeIdle = -1; Send $res 200 $utf8.GetBytes('atoms-connections') 'text/plain' }
    elseif ($path -eq '/bye') { if ($req.HttpMethod -eq 'POST' -and $sameSite) { $byeIdle = 0 }; Send $res 204 $null $null }
    elseif ($path -eq '/device-key' -or $path -eq '/save') {
      # A custom header forces browsers to ask permission for cross-site requests, which this server never grants.
      if ($req.HttpMethod -ne 'POST' -or $req.Headers['X-Atoms'] -ne '1' -or -not $sameSite) { Send $res 403 $null $null }
      elseif ($path -eq '/device-key') { $byeIdle = -1; Send $res 200 $secret 'application/octet-stream' }
      else {
        $q = Query $req
        $target = SafeTarget $q['folder'] $q['path']
        if (-not $target) { Send $res 400 $null $null }
        else {
          New-Item -ItemType Directory -Force -Path (Split-Path $target) | Out-Null
          $fs = [IO.File]::Create($target)
          try { $req.InputStream.CopyTo($fs) } finally { $fs.Close() }
          Send $res 200 $utf8.GetBytes($saveRoots[$q['folder']]) 'text/plain; charset=utf-8'
        }
      }
    }
    elseif ($static.ContainsKey($path) -and $req.HttpMethod -eq 'GET') {
      $byeIdle = -1
      $file = Join-Path $PSScriptRoot $static[$path][0]
      Send $res 200 ([IO.File]::ReadAllBytes($file)) $static[$path][1]
    }
    else { Send $res 404 $null $null }
  } catch { try { $res.StatusCode = 500 } catch {} }
  finally { try { $res.Close() } catch {} }
}
