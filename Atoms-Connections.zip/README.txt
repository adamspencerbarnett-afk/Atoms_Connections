ATOM'S CONNECTIONS  -  private space for family and friends
============================================================

Everything stays on your own computer, encrypted. Your browser talks directly
to your family and friends' browsers. No company server ever sees your posts,
photos or messages.


FIRST TIME
----------
1. Unzip this folder anywhere you like (for example your Documents folder).
   Keep the files together.

2. Double-click  "Start Atom's Connections".
   It opens the app in your normal web browser (Chrome or Edge work best).

   If Windows shows a blue "Windows protected your PC" box the first time,
   click "More info", then "Run anyway". That happens for any downloaded
   program and only needs doing once.

3. Type your name, pick a photo if you like, and tap "Create my space".
   There is no password. The app opens straight in from then on.


CONNECTING WITH SOMEONE
-----------------------
- Family/Friends  ->  Invite  gives you a code for ONE person. Copy it and
  send it to them by text or email. Each person needs their own code; tap
  Invite again for the next person. A code works once and expires in 7 days.

- Got a code from someone?  Family/Friends  ->  "Have an invite code?",
  paste it and tap Connect. You're connected automatically as soon as you
  are both online.


EVERY DAY
---------
- Always open the app with "Start Atom's Connections" (not by opening
  index.html, and not from a browser bookmark).
- Posts and messages only travel while both of you have the app open. If
  someone is away, things wait and arrive the next time you're both online.
- The Online / Offline switch at the top disconnects you completely.
- Settings -> Back up now  saves your photos, posts and chats into your
  Pictures and Documents folders, plus a password-locked restore file for
  moving to a new computer. Do this now and then.


WHAT'S IN THIS FOLDER
---------------------
Start Atom's Connections.cmd   double-click this
launcher.ps1                   the small helper it runs
index.html                     the app itself
vendor\peerjs.min.js           connection library
LICENSE.txt                    the user agreement (please read it once)


ABOUT
-----
Atom's Connections was written by Adam S. Barnett. All rights reserved.
You may use it for free and share unchanged copies with family and
friends at no cost. Please don't modify it or sell it. See LICENSE.txt.
Latest version: https://github.com/adamspencerbarnett-afk/Atoms_Connections
