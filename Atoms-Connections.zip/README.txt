ATOM'S CONNECTIONS  -  private space for family and friends
============================================================

Everything stays on your own computer, encrypted. Your browser talks directly
to your family and friends' browsers. No company server ever sees your posts,
photos or messages.


FIRST TIME
----------
1. Run  Atoms-Connections-Setup.exe  and follow the steps. It installs just
   for you (no administrator password) and can put a shortcut on your
   desktop. It also adds Atom's Connections to your Start menu.

   If Windows shows a blue "Windows protected your PC" box, click
   "More info", then "Run anyway". Windows does this for new programs from
   small makers until enough people have installed them.

   Using the zip instead? Unzip it anywhere and double-click
   AtomsConnections.exe. It puts a shortcut on your desktop for next time.

2. The app opens in your normal web browser (Chrome or Edge work best).
   Type your name, pick a photo if you like, and tap "Create my space".
   There is no password. The app opens straight in from then on.


CONNECTING WITH SOMEONE
-----------------------
- Family/Friends  ->  Invite  ->  Copy invite link, then paste it into a
  text, an email or any messenger to ONE person. They tap the link and you
  are connected automatically. Each person needs their own invite; tap
  Invite again for the next person. An invite works once and expires in
  7 days. Prefer a code? The same dialog shows one under "Prefer a code".

- Got an invite?  Tap the link: Atom's Connections opens and asks "Connect
  with ...?". Or go to  Family/Friends  ->  "Have an invite?", paste the
  link or code and tap Connect. You're connected automatically as soon as
  you are both online.

- New here with an invite?  Download from the link: the invite travels
  with the download, so after you install and type your name you're asked
  to connect right away. The first screen also has a box to paste a link
  or code.

- Introduce people: next to a name in Family/Friends, tap Introduce and
  pick who to introduce them to. Both get a Connect button; when both tap
  it they're connected. No codes, no email.


EVERY DAY
---------
- Always open the app with the "Atom's Connections" shortcut or Start menu
  entry (not from a browser bookmark).
- Posts and messages only travel while both of you have the app open. If
  someone is away, things wait and arrive the next time you're both online.
- Plugins (left menu) holds games and tools. PAC Runner is included: open it,
  or tap "Play with..." to invite family (1 to 4 players, arrow keys or
  WASD; M mutes the sound). Removing a plugin offers Archive (kept at the
  bottom of the page, restore any time) or Delete for good. Developers: see the guide there.
- The Online / Offline switch at the top disconnects you completely.
- Settings -> Back up now  saves your photos, posts and chats into your
  Pictures and Documents folders, plus a password-locked restore file for
  moving to a new computer. Do this now and then.


WHAT'S IN THIS FOLDER
---------------------
AtomsConnections.exe   the program (the whole app is inside it)
README.txt             this guide
LICENSE.txt            the user agreement (please read it once)

Uninstalling (Settings -> Apps) removes the program but keeps your posts,
photos and chats on this computer, so reinstalling picks up where you were.


BETA TESTING
------------
Atom's Connections is still in development. Right now it is for Windows
laptops and PCs (Chrome or Edge), not phones or tablets. Please send bug
reports (what you did, what you expected, what happened), wish lists and
ideas to atomsconnections@gmail.com. Your feedback shapes what comes next.


ABOUT
-----
Atom's Connections is made by Ultra Encode, LLC. All rights reserved.
Founder: Adam S. Barnett.
You may use it for free and share unchanged copies with family and
friends at no cost. Please don't modify it or sell it. See LICENSE.txt.
Latest version: https://atomsconnections.com
