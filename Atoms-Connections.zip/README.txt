ATOM'S CONNECTIONS  -  private space for family and friends
============================================================

Everything stays on your own computer, encrypted. Your browser talks directly
to your family and friends' browsers. No company server ever sees your posts,
photos or messages.


FIRST TIME
----------
1. Run  Atoms-Connections-Setup.exe  and follow the steps. It installs just
   for you (no administrator password) and can put a shortcut on your
   desktop. It also adds Atom's Connections to your Start menu.

   If Windows shows a blue "Windows protected your PC" box, click
   "More info", then "Run anyway". Windows does this for new programs from
   small makers until enough people have installed them.

   Using the zip instead? Unzip it anywhere and double-click
   AtomsConnections.exe. It puts a shortcut on your desktop for next time.

2. The app opens in your normal web browser (Chrome or Edge work best).
   Type your name, pick a photo if you like, and tap "Create my space".
   There is no password. The app opens straight in from then on.


CONNECTING WITH SOMEONE
-----------------------
- Family/Friends  ->  Invite  ->  Copy invite link, then paste it into a
  text, an email or any messenger to ONE person. They tap the link and you
  are connected automatically. Each person needs their own invite; tap
  Invite again for the next person. An invite works once and expires in
  7 days. Prefer a code? The same dialog shows one under "Prefer a code".

- Got an invite?  Tap the link: Atom's Connections opens and asks "Connect
  with ...?". Or go to  Family/Friends  ->  "Have an invite?", paste the
  link or code and tap Connect. You're connected automatically as soon as
  you are both online.

- New here with an invite?  Download from the link: the invite travels
  with the download, so after you install and type your name you're asked
  to connect right away. The first screen also has a box to paste a link
  or code.

- Files in chats: the paperclip (or drag and drop) attaches a photo, a video
  or any other file up to 100 MB. Files are packed when that helps (types
  that are compressed already are left alone), the card shows the speed and
  whether the path is direct or via a relay, and the other side gets a Save
  button. Big files travel in pieces, so a transfer that is interrupted
  carries on from where it stopped, and what you are looking at comes
  first ("Get first" on a card moves it to the front). A message that
  hasn't left yet shows who it's waiting for and an x to take it back; one
  to someone who is no longer connected says so and can be removed.

- File Box (bottom of the chat list): a shared box of files that follows
  the people you pick across their PCs, encrypted end to end, with no
  server. Press + to make one, name it, choose who is in it and what they
  may do (view and download, or also add and delete), and set its size cap
  per PC (1 GB unless you change it). Drop files in from the box page. A
  box always shows everything in it, but nothing downloads until you press
  Get on a file; in the box's settings (the gear) you can switch on "Keep
  this box downloaded and up to date" to have every file fetched by itself
  whenever someone who has it is online. You can remove a file from your
  own PC without affecting anyone, switch downloads for a box off, or leave
  it. Nothing in a box is ever sent to anyone who is not in it. "Put in a
  File Box" on a chat file card copies it into one of your boxes.

- Profile pages: tap your name at the bottom left (or any name on a post,
  or a row in Family/Friends) to see that person's page: cover photo, name
  and everything they've posted. On your own page, tap "Add a cover photo".

- Introduce people: next to a name in Family/Friends, tap Introduce and
  pick who to introduce them to. Both get a Connect button; when both tap
  it they're connected. No codes, no email.


EVERY DAY
---------
- Always open the app with the "Atom's Connections" shortcut or Start menu
  entry (not from a browser bookmark).
- Posts and messages only travel while both of you have the app open. If
  someone is away, things wait and arrive the next time you're both online.
- Plugins (left menu) holds games and tools. PAC Runner is included: open it,
  or tap "Play with..." to invite family (1 to 4 players, arrow keys or
  WASD; M mutes the sound). Removing a plugin offers Archive (kept at the
  bottom of the page, restore any time) or Delete for good. Some plugins ask for
  extras (notices, running in the background, a widget beside the feed, notes to
  people you pick): each is a switch on the plugin's card, off until you turn it on.
  "Permissions, explained" on that page says what each can and can never do.
- Two screens: a game opens in its own window on your other screen, so the
  app, your chats and calls stay in sight. The mouse moves freely between the
  screens: click the app to type, click the game to play. The first time, Edge
  asks to let the app place windows on your screens. "Bring here" in the game's
  bar puts it back over the app; Settings, Games turns it off.
  Developers: see the guide there.
- Calls: in any chat, the phone or camera button at the top rings that person
  (or everyone online in a group). They see Answer / Decline at the top of
  their page; you can both keep browsing, play a game or read the feed while
  you talk: the call floats over the page. Drag it by its title to any spot,
  pull the corner to make the video bigger, shrink it to a bar, or go full
  screen. Mute, camera, Share your screen, picture quality (High, Medium,
  Low; Low keeps up on a slow connection) and Hang up are there. Share your
  screen shows the people in the call your whole screen, one window or one
  browser tab (your browser lists them; pick there). What you share goes only
  to the people in that call, is never recorded, and a "Sharing" chip stays
  at the top of the page until you stop. The screen shows big on the left
  with the person sharing on top of the column at the right. A shared screen
  always keeps its full size so text stays readable; the quality setting
  only changes how smoothly it moves. In a group, "Join the call" shows
  in the chat while a call is on, so people can come and go. Calls go straight
  between your computers, encrypted, and only ring while the other person's
  app is open; otherwise they find a missed-call note in the chat. Settings ->
  Calls has the ring switch, a relay option that hides your address, the
  picture quality, and the choice of microphone, camera and speakers (also
  under the gear on a call). Settings -> Privacy & connection has a switch
  for the public relay that is used only when a direct connection fails,
  and one that lets your PC carry encrypted bytes between two of your
  people who cannot reach each other directly (a friend you share does the
  same for you: the list then says "Online - via Eve"). Big files come from
  everyone who has them at once, over extra connections when several files
  are queued.
  If the other person hears themselves echo, you are probably on a camera's
  microphone with speakers: pick a headset there.
- Music: the Music button above your name (bottom left) opens your music.
  Add songs or a folder from this PC, or drop them on the popup; they are
  converted to a compact format, kept encrypted on this PC and never
  uploaded anywhere. Play shows a small compass player you can drag around:
  the middle plays or pauses, the side pads skip songs, the top and bottom
  pads skip albums, the ring is the progress bar (drag it to seek) and the
  mouse wheel over it sets the volume. Music keeps playing while you browse,
  turns down when a call rings and pauses while you are on a call. The ...
  menu on an album or song has Share: pick a chat or your feed. The other
  person gets a card, and the songs travel only when they press Play or Add.
  Share music you own, with your family and friends.
- The Online / Offline switch at the top disconnects you completely.
- Settings -> Back up now  saves your photos, posts and chats into your
  Pictures and Documents folders, plus a password-locked restore file for
  moving to a new computer. Do this now and then.


WHAT'S IN THIS FOLDER
---------------------
AtomsConnections.exe   the program (the whole app is inside it)
README.txt             this guide
LICENSE.txt            the user agreement (please read it once)

Uninstalling (Settings -> Apps) removes the program but keeps your posts,
photos and chats on this computer, so reinstalling picks up where you were.


BETA TESTING
------------
Atom's Connections is still in development. Right now it is for Windows
laptops and PCs (Chrome or Edge), not phones or tablets. Please send bug
reports (what you did, what you expected, what happened), wish lists and
ideas to atomsconnections@gmail.com. Your feedback shapes what comes next.


ABOUT
-----
Atom's Connections is made by Ultra Encode, LLC. All rights reserved.
Founder: Adam S. Barnett.
You may use it for free and share unchanged copies with family and
friends at no cost. Please don't modify it or sell it. See LICENSE.txt.
Latest version: https://atomsconnections.com
